#classes and subclasses to import
import cv2
import numpy as np
import os
global filename
filename = 'results1A_584.csv'
#################################################################################################
# DO NOT EDIT!!!
#################################################################################################
#subroutine to write results to a csv
def writecsv(color,shape,(cx,cy)):
    global filename
    #open csv file in append mode
    filep = open(filename,'a')
    # create string data to write per image
    datastr = "," + color + "-" + shape + "-" + str(cx) + "-" + str(cy)
    #write to csv
    filep.write(datastr)
    filep.close()
def main(path):
#####################################################################################################
    #Write your code here!!!
#####################################################################################################
    img = cv2.imread(path)#reading the test image
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    ret,thresh = cv2.threshold(gray,127,255,0)
    flags, contours, hierarchy = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)#generating the list of contours
    a=[]#to store number of vertices of each contour
    b=[]#to store the list of vertices of all the contours
    ls=[]#list to be returned
    ls.append(path[2:])
    s=""
    s1=""
    for i in contours:
        approx = cv2.approxPolyDP(i,0.01*cv2.arcLength(i,True),True)
        #approx has the list of the list of x,y pair coord. of vertices the shape
        x = len(approx)
        a.append(x)
        b.append(approx)
    for i in range(1,len(contours)):
        #it starts from 1 to exclude the whole frame contour itself.
        #following code is for centroid calculation
        M = cv2.moments(contours[i])
        cx = int(M['m10']/M['m00'])
        cy = int(M['m01']/M['m00'])
        px=img[cy,cx]#list of bgr values of the centroid to check the shape colour.
        s="("+str(cx)+","+str(cy)+")";
        if px[0]==0 and px[1]==0:
            s1="Red"
            cv2.putText(img,"Red", (cx-40,cy-40), cv2.FONT_HERSHEY_SIMPLEX, .5, 0,1,cv2.LINE_AA)
            cv2.putText(img,s, (cx,cy), cv2.FONT_HERSHEY_SIMPLEX, .4, 0,1,cv2.LINE_AA)
        elif px[2]==0 and px[1]==0:
            s1="Blue"
            cv2.putText(img,"Blue", (cx-40,cy-40), cv2.FONT_HERSHEY_SIMPLEX, .5,0,1,cv2.LINE_AA)
            cv2.putText(img,s, (cx,cy), cv2.FONT_HERSHEY_SIMPLEX, .4, 0,1,cv2.LINE_AA)
        elif px[0]==0 and px[2]==0:
            s1="Green"
            cv2.putText(img,"Green", (cx-40,cy-40), cv2.FONT_HERSHEY_SIMPLEX, .5,0,1,cv2.LINE_AA)
            cv2.putText(img,s, (cx,cy), cv2.FONT_HERSHEY_SIMPLEX, .4, 0,1,cv2.LINE_AA)
        s2=s1;
        if a[i]==3:
            s1 = s1+"-"+"Triangle"
            s3="Triangle"
            cv2.putText(img,"Triangle",(cx-20,cy-20), cv2.FONT_HERSHEY_SIMPLEX, .5,0,1,cv2.LINE_AA)
        elif a[i]==4:
            distx=b[i][0][0][0]-b[i][1][0][0]
            distx=distx**2
            disty=b[i][0][0][1]-b[i][1][0][1]
            disty=disty**2
            dist1=distx+disty
            dist1=int(dist1**(1.0/2))
            distx=b[i][2][0][0]-b[i][1][0][0]
            distx=distx**2
            disty=b[i][2][0][1]-b[i][1][0][1]
            disty=disty**2
            dist2=distx+disty
            dist2=int(dist2**(1.0/2))
            distx=b[i][3][0][0]-b[i][2][0][0]
            distx=distx**2
            disty=b[i][3][0][1]-b[i][2][0][1]
            disty=disty**2
            dist3=distx+disty
            dist3=int(dist3**(1.0/2))
            distx=b[i][3][0][0]-b[i][0][0][0]
            distx=distx**2
            disty=b[i][3][0][1]-b[i][0][0][1]
            disty=disty**2
            dist4=distx+disty
            dist4=int(dist4**(1.0/2))
            if (dist1/dist2==1 and dist3/dist2==1 and dist3/dist4==1):
                s1 = s1+"-"+"Rhombus"
                s3="Rhombus"
                cv2.putText(img,"Rhombus",(cx-20,cy-20), cv2.FONT_HERSHEY_SIMPLEX, .5,0,1,cv2.LINE_AA)
            else:
                s1 = s1+"-"+"Trapezium"
                s3="Trapezium"
                cv2.putText(img,"Trapezium",(cx-20,cy-20), cv2.FONT_HERSHEY_SIMPLEX, .5,0,1,cv2.LINE_AA)
                
        elif a[i]==5:
            s1 = s1+"-"+"Pentagon"
            s3="Pentagon"
            cv2.putText(img,"Pentagon",(cx-20,cy-20), cv2.FONT_HERSHEY_SIMPLEX, .5,0,1,cv2.LINE_AA)
        elif a[i]==6:
            s1 = s1+"-"+"Hexagon"
            s3="Hexagon"
            cv2.putText(img,"Hexagon",(cx-20,cy-20), cv2.FONT_HERSHEY_SIMPLEX, .5,0,1,cv2.LINE_AA)
        elif a[i]>=7:
            s1 = s1+"-"+"Circle"
            s3="Circle"
            cv2.putText(img,"Circle",(cx-20,cy-20), cv2.FONT_HERSHEY_SIMPLEX, .5,0,1,cv2.LINE_AA)
        s1 = s1+"-"+str(cx)+"-"+str(cy)
        l=[]
        l.append(s1)
        writecsv(s2,s3,(cx,cy))
        ls.append(l)
    s=path[:len(path)-4]+"output.png"
    cv2.imwrite(s,img)
    
    return ls

#################################################################################################
# DO NOT EDIT!!!
#################################################################################################
#main where the path is set for the directory containing the test images
if __name__ == "__main__":
    mypath = '.'
    #getting all files in the directory
    onlyfiles = [os.path.join(mypath, f) for f in os.listdir(mypath) if f.endswith(".png")]
    #iterate over each file in the directory
    for fp in onlyfiles:
        #Open the csv to write in append mode
        filep = open(filename,'a')
        #this csv will later be used to save processed data, thus write the file name of the image 
        filep.write(fp)
        #close the file so that it can be reopened again later
        filep.close()
        #process the image
        data = main(fp)
        print data
        #open the csv
        filep = open(filename,'a')
        #make a newline entry so that the next image data is written on a newline
        filep.write('\n')
        #close the file
        filep.close()
