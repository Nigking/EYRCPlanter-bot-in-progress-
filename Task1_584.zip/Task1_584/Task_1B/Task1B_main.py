#classes and subclasses to import
import cv2
import numpy as np
import os
global path_to_video_mp4_file_with_name
path_to_video_mp4_file_with_name='./Video.mp4'
global filename
filename = 'results1B_584.csv'
#################################################################################################
# DO NOT EDIT!!!
#################################################################################################
#subroutine to write results to a csv
def writecsv(color,shape,(cx,cy)):
    global filename
    #open csv file in append mode
    filep = open(filename,'a')
    # create string data to write per image
    datastr = "," + color + "-" + shape + "-" + str(cx) + "-" + str(cy)
    #write to csv
    filep.write(datastr)
    filep.close()
#################################################################################################
# DO NOT EDIT!!!
#################################################################################################
def blend_transparent(face_img, overlay_t_img):
    # Split out the transparency mask from the colour info
    overlay_img = overlay_t_img[:,:,:3] # Grab the BRG planes
    overlay_mask = overlay_t_img[:,:,3:]  # And the alpha plane

    # Again calculate the inverse mask
    background_mask = 255 - overlay_mask

    # Turn the masks into three channel, so we can use them as weights
    overlay_mask = cv2.cvtColor(overlay_mask, cv2.COLOR_GRAY2BGR)
    background_mask = cv2.cvtColor(background_mask, cv2.COLOR_GRAY2BGR)

    # Create a masked out face image, and masked out overlay
    # We convert the images to floating point in range 0.0 - 1.0
    face_part = (face_img * (1 / 255.0)) * (background_mask * (1 / 255.0))
    overlay_part = (overlay_img * (1 / 255.0)) * (overlay_mask * (1 / 255.0))

    # And finally just add them together, and rescale it back to an 8bit integer image    
    return np.uint8(cv2.addWeighted(face_part, 255.0, overlay_part, 255.0, 0.0))


def main(video_file_with_path):
    cap = cv2.VideoCapture(video_file_with_path)
    image_red = cv2.imread("Overlay_Images\\yellow_flower.png",-1)
    image_blue = cv2.imread("Overlay_Images\\pink_flower.png",-1)
    image_green = cv2.imread("Overlay_Images\\red_flower.png",-1)

#####################################################################################################
    #Write your code here!!!
#####################################################################################################
    fourcc = cv2.VideoWriter_fourcc(*'XVID')#set video codec
    out = cv2.VideoWriter('video_output.mp4',fourcc, 16.5723605467, (1280,720))#create output video object
    ret=True
    x1=[]
    y1=[]
    while(ret):
        ret, img = cap.read()#fileread
        if ret == False:
            break
        gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
        ret,thresh = cv2.threshold(gray,127,255,0)
        flags, contours, hierarchy = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        a=[]#to store number of vertices of each contour
        b=[]#to store the list of vertices of all the contours
        for i in contours:
            approx = cv2.approxPolyDP(i,0.01*cv2.arcLength(i,True),True)#approx has the list of the list of x,y pair coord. of vertices the shape
            x = len(approx)
            a.append(x)
            b.append(approx)
        for i in range(1,len(contours)):#it starts from 1 to exclude the whole frame contour itself.
        #following code is for centroid calculation and bounding rectangle subsequently detect object along with its colour and shape then overlaying the respective flower on the respective object 
            current_contour = contours[i]
            x,y,w,h = cv2.boundingRect(current_contour)#calculte bounding rectangle
            M = cv2.moments(contours[i])
            cx = int(M['m10']/M['m00'])
            cy = int(M['m01']/M['m00'])
            px=img[cy,cx]
            s="("+str(cx)+","+str(cy)+")";
            if px[0]==0 and px[1]==0:
                color=image_red
                colorr="Red"
            elif px[2]==0 and px[1]==0:
                color=image_blue
                colorr="Blue"
            elif px[0]==0 and px[2]==0:
                color=image_green
                colorr="Green"
            if a[i]==3:
                s3="Triangle"
            elif a[i]==4:
                distx=b[i][0][0][0]-b[i][1][0][0]
                distx=distx**2
                disty=b[i][0][0][1]-b[i][1][0][1]
                disty=disty**2
                dist1=distx+disty
                dist1=int(dist1**(1.0/2))
                distx=b[i][2][0][0]-b[i][1][0][0]
                distx=distx**2
                disty=b[i][2][0][1]-b[i][1][0][1]
                disty=disty**2
                dist2=distx+disty
                dist2=int(dist2**(1.0/2))
                distx=b[i][3][0][0]-b[i][2][0][0]
                distx=distx**2
                disty=b[i][3][0][1]-b[i][2][0][1]
                disty=disty**2
                dist3=distx+disty
                dist3=int(dist3**(1.0/2))
                distx=b[i][3][0][0]-b[i][0][0][0]
                distx=distx**2
                disty=b[i][3][0][1]-b[i][0][0][1]
                disty=disty**2
                dist4=distx+disty
                dist4=int(dist4**(1.0/2))
                if (dist1/dist2==1 and dist3/dist2==1 and dist3/dist4==1):
                    s3="Rhombus"
                else:
                    s3="Trapezium"                
            elif a[i]==5:
                s3="Pentagon"
            elif a[i]==6:
                s3="Hexagon"
            elif a[i]>=7:
                s3="Circle"
            if x not in x1:#newly appeared object
                x1.append(x)
                y1.append(y)
                w2=w
                h2=h
                y2=y
                x2=x
                color2=color
                writecsv(colorr,s3,(cx,cy))#writing to csv
            cv2.waitKey(40)
            overlay_image = cv2.resize(color2,(w2,h2))#overlaying
            img[y2:y2+h2,x2:x2+w2,:] = blend_transparent(img[y2:y2+h2,x2:x2+w2,:], overlay_image)
        out.write(img)#write to the video file
        cv2.waitKey(40)
    cap.release()
    out.release()#releasing resources
    cv2.destroyAllWindows()
#################################################################################################
# DO NOT EDIT!!!
#################################################################################################
#main where the path is set for the directory containing the test images
if __name__ == "__main__":
    main(path_to_video_mp4_file_with_name)
